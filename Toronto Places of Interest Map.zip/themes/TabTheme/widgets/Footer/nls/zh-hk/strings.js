define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "頁腳"
});