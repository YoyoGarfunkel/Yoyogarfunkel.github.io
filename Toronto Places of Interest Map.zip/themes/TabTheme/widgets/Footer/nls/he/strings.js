define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "כותרת תחתונה"
});