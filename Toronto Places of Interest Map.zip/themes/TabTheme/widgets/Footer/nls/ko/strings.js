define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "바닥글"
});