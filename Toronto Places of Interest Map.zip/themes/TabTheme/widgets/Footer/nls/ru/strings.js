define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "Нижний колонтитул"
});