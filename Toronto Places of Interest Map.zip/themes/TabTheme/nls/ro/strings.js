define({
  "_themeLabel": "Temă cu file",
  "_layout_default": "Aspect implicit",
  "_layout_layout1": "Aspectul 1"
});