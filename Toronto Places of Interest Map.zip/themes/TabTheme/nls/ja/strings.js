define({
  "_themeLabel": "タブ テーマ",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_layout1": "レイアウト 1"
});