define({
  "_themeLabel": "Θέμα καρτέλας",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_layout1": "Διάταξη 1"
});