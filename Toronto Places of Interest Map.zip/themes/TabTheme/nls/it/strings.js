define({
  "_themeLabel": "Tema a schede",
  "_layout_default": "Layout predefinito",
  "_layout_layout1": "Layout 1"
});