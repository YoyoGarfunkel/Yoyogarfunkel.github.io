define({
  "_themeLabel": "Tema do Separador",
  "_layout_default": "Layout predefinido",
  "_layout_layout1": "Layout 1"
});