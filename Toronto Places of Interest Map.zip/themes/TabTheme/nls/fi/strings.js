define({
  "_themeLabel": "Välilehdet -teema",
  "_layout_default": "Oletusasettelu",
  "_layout_layout1": "Asettelu 1"
});