define({
  "_themeLabel": "Vahekaardi kujundus",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_layout1": "Paigutus 1"
});