define({
  "_themeLabel": "موضوع علامة التبويب",
  "_layout_default": "تخطيط افتراضي",
  "_layout_layout1": "تخطيط 1"
});